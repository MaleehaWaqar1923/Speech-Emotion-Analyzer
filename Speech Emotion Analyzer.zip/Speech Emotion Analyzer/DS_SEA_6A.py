import librosa
import soundfile
import os
import glob
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

# DataFlair - Extract features (mfcc, chroma, mel) from a sound file
def extract_feature(file_name, mfcc, chroma, mel):
    with soundfile.SoundFile(file_name) as sound_file:
        X, sample_rate = librosa.load(file_name, res_type='kaiser_fast')
        if chroma:
            stft = np.abs(librosa.stft(X))
        result = np.array([])
        if mfcc:
            mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
            result = np.hstack((result, mfccs))
        if chroma:
            chroma = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
            result = np.hstack((result, chroma))
        if mel:
            mel = np.mean(librosa.feature.melspectrogram(y=X, sr=sample_rate).T, axis=0)
            result = np.hstack((result, mel))
    return result

# DataFlair - Emotions in the RAVDESS dataset
emotions = {
    '01': 'neutral',
    '02': 'calm',
    '03': 'happy',
    '04': 'sad',
    '05': 'angry',
    '06': 'fearful',
    '07': 'disgust',
    '08': 'surprised'
}

# DataFlair - Emotions to observe
observed_emotions = ['sad', 'happy', 'fearful', 'disgust']

def load_data(test_size=0.2):
    x, y = [], []
    for file in glob.glob(r"C:\Users\Dell\Downloads\speech-emotion-recognition-ravdess-data\Actor_*\*.wav"):
        file_name = os.path.basename(file)
        emotion = emotions[file_name.split("-")[2]]
        if emotion not in observed_emotions:
            continue
        feature = extract_feature(file, mfcc=True, chroma=True, mel=True)
        x.append(feature)
        y.append(emotion)
    return train_test_split(np.array(x), y, test_size=test_size)

# DataFlair - Split the dataset
x_train, x_test, y_train, y_test = load_data(test_size=0.25)

# DataFlair - Get the shape of the training and testing datasets
print("Training data shape:", x_train.shape)
print("Test data shape:", x_test.shape)

# DataFlair - Get the number of features extracted
print(f'Features extracted: {x_train.shape[1]}')

# DataFlair - Initialize the Multi Layer Perceptron Classifier
model = MLPClassifier(alpha=0.01, batch_size=256, epsilon=1e-08, hidden_layer_sizes=(300,), learning_rate='adaptive', max_iter=500)

# DataFlair - Train the model
model.fit(x_train, y_train)

# DataFlair - Predict for the test set
y_pred = model.predict(x_test)

# DataFlair - Calculate the accuracy of our model
accuracy = accuracy_score(y_true=y_test, y_pred=y_pred)

# DataFlair - Print the accuracy
print("Accuracy: {:.2f}%".format(accuracy*100))

# Plot the distribution of emotions in the training dataset
sns.countplot(y_train)
plt.xlabel('Number of samples')
plt.ylabel('Emotion')
plt.title('Distribution of emotions in the training dataset')
plt.show()

# Create the confusion matrix
cm = confusion_matrix(y_test, y_pred)

# Plot the confusion matrix using seaborn
sns.heatmap(cm, annot=True, xticklabels=observed_emotions, yticklabels=observed_emotions, cmap='Blues')
plt.xlabel('Predicted Emotion')
plt.ylabel('True Emotion')
plt.title('Confusion Matrix')
plt.show()

# Create a DataFrame to store the MFCC coefficients
mfcc_df = pd.DataFrame(x_train[:, :40], columns=[f'MFCC{i+1}' for i in range(40)])
# Add a column for the true emotion labels
mfcc_df['Emotion'] = y_train
# Save the DataFrame to an excel file
mfcc_df.to_excel(r'C:\Users\Dell\Desktop\ids project\mfcc_coefficients.xlsx', index=False)

df = pd.read_excel(r"C:\Users\Dell\Desktop\ids project\mfcc_coefficients.xlsx")
df.head(5)

# Create a DataFrame to store the Chroma features
chroma_df = pd.DataFrame(x_train[:, 40:52], columns=[f'Chroma{i+1}' for i in range(12)])
# Add a column for the true emotion labels
chroma_df['Emotion'] = y_train
# Save the DataFrame to an excel file
chroma_df.to_excel(r"C:\Users\Dell\Desktop\ids project\chroma_features.xlsx", index=False)

dt = pd.read_excel(r"C:\Users\Dell\Desktop\ids project\chroma_features.xlsx")
dt.head(5)

# Create a DataFrame to store the Mel Spectrogram features
mel_df = pd.DataFrame(x_train[:, 52:], columns=[f'Mel{i+1}' for i in range(128)])
# Add a column for the true emotion labels
mel_df['Emotion'] = y_train
# Save the DataFrame to an excel file
mel_df.to_excel(r"C:\Users\Dell\Desktop\ids project\Mel_Spectrogram_features.xlsx", index=False)

d = pd.read_excel(r"C:\Users\Dell\Desktop\ids project\Mel_Spectrogram_features.xlsx")
d.head(5)

# Group the Chroma features by emotion
grouped_chroma = chroma_df.groupby('Emotion').mean()
# Plot the Chroma features for each emotion
grouped_chroma.T.plot(kind='line')
plt.xlabel('Chroma Features')
plt.ylabel('Amplitude')
plt.title('Chroma features by Emotion')
plt.legend(loc='best')
plt.show()

# Group the Mel Spectrogram features by emotion
grouped_mel = mel_df.groupby('Emotion').mean()
# Plot the Mel Spectrogram features for each emotion
grouped_mel.T.plot(kind='line')
plt.xlabel('Mel Spectrogram Features')
plt.ylabel('Amplitude')
plt.title('Mel Spectrogram features by Emotion')
plt.legend(loc='best')
plt.show()

# Load and plot example sound files
def plot_wave_plot_happy():
    file_name = r"C:\Users\Dell\Downloads\speech-emotion-recognition-ravdess-data\Actor_03\03-01-01-01-01-01-03.wav"
    data, sr = librosa.load(file_name)
    plt.figure(figsize=(14, 5))
    plt.plot(data)
    plt.title(f'Wave plot of a "happy" emotion sound')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.show()

def plot_wave_plot_disgust():
    file_name = r"C:\Users\Dell\Downloads\speech-emotion-recognition-ravdess-data\Actor_01\03-01-01-01-01-02-01.wav"
    data, sr = librosa.load(file_name)
    plt.figure(figsize=(14, 5))
    plt.plot(data)
    plt.title(f'Wave plot of a "disgust" emotion sound')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.show()

def plot_wave_plot_fear():
    file_name = r"C:\Users\Dell\Downloads\speech-emotion-recognition-ravdess-data\Actor_01\03-01-01-01-02-01-01.wav"
    data, sr = librosa.load(file_name)
    plt.figure(figsize=(14, 5))
    plt.plot(data)
    plt.title(f'Wave plot of a "fear" emotion sound')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.show()

def plot_wave_plot_sad():
    file_name = r"C:\Users\Dell\Downloads\speech-emotion-recognition-ravdess-data\Actor_01\03-01-01-01-02-01-01.wav"
    data, sr = librosa.load(file_name)
    plt.figure(figsize=(14, 5))
    plt.plot(data)
    plt.title(f'Wave plot of a "sad" emotion sound')
    plt.xlabel('Time')
    plt.ylabel('Amplitude')
    plt.show()

# Example usage:
plot_wave_plot_happy()
plot_wave_plot_disgust()
plot_wave_plot_fear()
plot_wave_plot_sad()
